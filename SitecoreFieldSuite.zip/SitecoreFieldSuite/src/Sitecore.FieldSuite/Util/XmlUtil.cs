﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Serialization;
using Sitecore.SharedSource.FieldSuite.Controls.GeneralLinks;

namespace Sitecore.SharedSource.FieldSuite.Util
{
	public class XmlUtil
	{
		public static string XmlSerializeToString(object objectInstance)
		{
			XmlSerializer serializer = new XmlSerializer(typeof(GeneralLinkItem));
			StringBuilder builder = new StringBuilder();

			XmlWriterSettings settings = new XmlWriterSettings();
			settings.OmitXmlDeclaration = true;

			XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
			ns.Add("", "");

			using (XmlWriter stringWriter = XmlWriter.Create(builder, settings))
			{
				serializer.Serialize(stringWriter, objectInstance, ns);
				return builder.ToString();
			}
		}

		public static string ReplaceSpecialChar(string val)
        {
			var returnVal = val;
			if (val.Contains("&amp;amp;"))
            {
				returnVal= val.Replace("&amp;amp;", "&amp;").Replace("#38;", string.Empty);
			}
			
			return returnVal;
        }

		public static T XmlDeserializeFromString<T>(string objectData)
		{
			return (T)XmlDeserializeFromString(objectData, typeof(T));
		}

		public static object XmlDeserializeFromString(string objectData, Type type)
		{
			var serializer = new XmlSerializer(type);
			object result;

			using (TextReader reader = new StringReader(objectData))
			{
				result = serializer.Deserialize(reader);
			}

			return result;
		}
	}
}
